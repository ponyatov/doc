// =====================================================
// ����������� ���� ����������
//
// (C) ������ �.�, 1997
//
// E-mail: frolov@glas.apc.org
// WWW:    http://www.glasnet.ru/~frolov
//            ���
//         http://www.dials.ccas.ru/frolov
// =====================================================
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <memory.h>
               
extern void GET_CPU_MODEL(void);
extern char VENDOR_ID_MSG[12];
extern char CPU_MODEL;
extern long CPU_SIGNATURE;
extern long FEATURES_ECX;
extern long FEATURES_EDX;
extern long FEATURES_EBX;

int main(void)
{         
  char buf[128];
  printf("*CPU Information*, (C) A. Frolov, 1997\n\n");

  GET_CPU_MODEL();
  
  printf("CPU model: %d\n", (unsigned)CPU_MODEL);
  
  if(CPU_MODEL >= 5)
  {
    memcpy(buf, VENDOR_ID_MSG, 12);
    buf[12] = 0;
    printf("Vendor ID: %s\n\n", buf);
  
    printf("CPU Signature    %08.8X\n", CPU_SIGNATURE);
    printf("CPU Feature EDX  %08.8X\n\n", FEATURES_EDX);
    
    printf("CPU type:     %d\n", (CPU_SIGNATURE & 0x3000) >> 12);
    printf("CPU family:   %d\n", (CPU_SIGNATURE & 0xF00) >> 8);
    printf("CPU model:    %d\n", (CPU_SIGNATURE & 0xF0) >> 4);
    printf("CPU stepping: %d\n\n", CPU_SIGNATURE & 0xF);
    
    if(FEATURES_EDX & 0x1)
      printf("FPU detected\n");

    if(FEATURES_EDX & 0x800000)
      printf("MMX supported\n");
  }

  getch();
  return 0;
}