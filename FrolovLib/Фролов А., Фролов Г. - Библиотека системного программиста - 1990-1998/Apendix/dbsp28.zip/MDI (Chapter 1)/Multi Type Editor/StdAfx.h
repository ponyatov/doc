// stdafx.h 
//

#define VC_EXTRALEAN		

#include <afxwin.h>         
#include <afxext.h>         
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxtempl.h>



