// HttpViewDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHttpViewDlg dialog

class CHttpViewDlg : public CDialog
{
// Construction
public:
	~CHttpViewDlg();
	CHttpViewDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CHttpViewDlg)
	enum { IDD = IDD_HTTPVIEW_DIALOG };
	CString	m_UrlAddress;
	CString	m_View;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHttpViewDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CInternetSession* m_InternetSession;
	CHttpConnection* m_HttpConnection;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CHttpViewDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonGet();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
