#include <stdio.h>
#include <dos.h>

void main(void);

void main(void) {

	union REGS  rg;
	int   i;

	 for(i=0; i<5; i++) {

		rg.h.ah = 5;

		rg.h.cl = '*';
		rg.h.ch = 9;

		int86(0x16, &rg, &rg);

	 }
}
