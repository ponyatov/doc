//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MultiMenu.rc
//
#define IDR_RESTRICT_MENU               106
#define IDR_FULL_MENU                   107
#define IDR_ACCELERATOR                 108
#define ID_FILE_EXIT                    40009
#define ID_MISSION_PROCESS              40013
#define ID_HELP_HELPINDEX               40014
#define ID_HELP_CONTEXTHELP             40015
#define ID_HELP_SYSTEMINFO              40016
#define ID_MISSION_CONSTRUCT            40017
#define ID_MENU_RESTRICT                40019
#define ID_MENU_FULL                    40020
#define ID_MENU_DISABLE                 40025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40027
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
