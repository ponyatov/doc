#include <stdio.h>

void main(void) {

	char	*ptr;
	char	out_str[] = "\a\n putchar \n putc \a";

	// �⮡ࠦ��� ��ப� out_str
	for(ptr = out_str; *ptr; putchar(*(ptr++)));

	return;
}
