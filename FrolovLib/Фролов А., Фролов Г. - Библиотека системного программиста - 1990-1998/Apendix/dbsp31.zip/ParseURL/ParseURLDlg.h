// ParseURLDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CParseURLDlg dialog

class CParseURLDlg : public CDialog
{
// Construction
public:
	CParseURLDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CParseURLDlg)
	enum { IDD = IDD_PARSEURL_DIALOG };
	CString	m_ObjectName;
	CString	m_PortNumber;
	CString	m_ServerName;
	CString	m_ServiceType;
	CString	m_UrlAddress;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CParseURLDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CParseURLDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonConvert();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
