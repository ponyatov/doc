// CONF.C
// ��।���� �㭪�� GetConfig(), ���뢠���� 䠩� ���䨣��樨

// (C) �஫�� �.�., 1995
// ���� E-mail: frolov@glas.apc.org


#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "conf.h"

void Number( unsigned *num );
void Token( char *string );


	FILE *CfgFile;
	char LineBuf[256];


	extern char initialize[80];
	extern char dropline[80];
	extern char autoanswer[80];

	extern char dialPrefix[80];
	extern char dialSuffix[80];
	extern char dialNumber[80];

	extern unsigned   chardelay;
	extern unsigned   dialTimeout;
	extern unsigned   modemTimeout;
	extern unsigned   answerTimeout;

	extern unsigned   speed;

	extern char *device;

/**
*.Name         GetConfig
*
*.Descr        �㭪�� ���뢠�� ����� �� 䠩�� setup.cfg
*
*.Proto        void getconfig(void)
*
*.Params       �� �ᯮ������
*
*.Return       �� �ᯮ������
*
*.Sample       modem.c
**/
void GetConfig(void) {

	CfgFile=fopen("setup.cfg","r");

	if(CfgFile == NULL) {
		cprintf("\r\n��������� 䠩� SETUP.CFG.");
		exit(-1);
	}

	// ������塞 �������� ��६����

	for(;;) {
		fgets(LineBuf,255,CfgFile);
		if(feof(CfgFile)) break;

		STRIP(LineBuf);

		if(OPERATOR("Dropline"))         Token( dropline );
		else if(OPERATOR("Initialize"))  Token( initialize );
		else if(OPERATOR("AutoAnswerr")) Token( autoanswer );

		else if(OPERATOR("DialNumber"))  Token( dialNumber );
		else if(OPERATOR("DialPrefix"))  Token( dialPrefix );
		else if(OPERATOR("DialSuffix"))  Token( dialSuffix );
		else if(OPERATOR("Device"))      Token( device );


		else if(OPERATOR("CharDelay"))      Number( &chardelay );
		else if(OPERATOR("DialTimeout"))    Number( &dialTimeout );
		else if(OPERATOR("ModemTimeout"))   Number( &modemTimeout );

		else if(OPERATOR("TimeoutAnswer"))  Number( &answerTimeout );
		else if(OPERATOR("Speed"))          Number( &speed );
	}

	fclose(CfgFile);
}

//=====================================================
// �㭪�� Token
//=====================================================
void Token( char *string ) {

	char *next;

	next = strcpy( string, strchr( LineBuf, ' ' ) + 1 );
	if(next == NULL) string[0] = '\0';
}

//=====================================================
// �㭪�� Number
//=====================================================
void Number( unsigned *num ) {

	char buf[80];

	strcpy( buf, strchr( LineBuf, ' ' ) + 1 );
	*num = atoi( buf );
}


