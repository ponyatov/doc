// MultiDoc.h : ����� CMultiDoc 
//
/////////////////////////////////////////////////////////////////////////////

class CMultiDoc : public CDocument
{
protected: 
	CMultiDoc();
	DECLARE_DYNCREATE(CMultiDoc)

// Attributes
public:

// Operations
public:

// Overrides

	//{{AFX_VIRTUAL(CMultiDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMultiDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif


protected:
	//{{AFX_MSG(CMultiDoc)
		// NOTE 
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
