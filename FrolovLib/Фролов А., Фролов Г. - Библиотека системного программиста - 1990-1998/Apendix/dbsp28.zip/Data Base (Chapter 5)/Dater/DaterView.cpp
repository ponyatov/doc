// DaterView.cpp : implementation of the CDaterView class
//

#include "stdafx.h"
#include "Dater.h"

#include "DaterSet.h"
#include "DaterDoc.h"
#include "DaterView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaterView

IMPLEMENT_DYNCREATE(CDaterView, CRecordView)

BEGIN_MESSAGE_MAP(CDaterView, CRecordView)
	//{{AFX_MSG_MAP(CDaterView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDaterView construction/destruction

CDaterView::CDaterView()
	: CRecordView(CDaterView::IDD)
{
	//{{AFX_DATA_INIT(CDaterView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CDaterView::~CDaterView()
{
}

void CDaterView::DoDataExchange(CDataExchange* pDX)
{
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDaterView)
	DDX_FieldText(pDX, IDC_ADDRESS, m_pSet->m_ADDRESS, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_ADDRESS, 255);
	DDX_FieldText(pDX, IDC_NAME, m_pSet->m_NAME, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_NAME, 255);
	DDX_FieldText(pDX, IDC_PHONE, m_pSet->m_PHONE, m_pSet);
	DDV_MaxChars(pDX, m_pSet->m_PHONE, 255);
	DDX_FieldText(pDX, IDC_PRIORITY, m_pSet->m_PRIORITY, m_pSet);
	DDV_MinMaxLong(pDX, m_pSet->m_PRIORITY, 0, 1000);
	//}}AFX_DATA_MAP
}

BOOL CDaterView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRecordView::PreCreateWindow(cs);
}

void CDaterView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_daterSet;
	CRecordView::OnInitialUpdate();
}

/////////////////////////////////////////////////////////////////////////////
// CDaterView diagnostics

#ifdef _DEBUG
void CDaterView::AssertValid() const
{
	CRecordView::AssertValid();
}

void CDaterView::Dump(CDumpContext& dc) const
{
	CRecordView::Dump(dc);
}

CDaterDoc* CDaterView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDaterDoc)));
	return (CDaterDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDaterView database support
CRecordset* CDaterView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CDaterView message handlers
