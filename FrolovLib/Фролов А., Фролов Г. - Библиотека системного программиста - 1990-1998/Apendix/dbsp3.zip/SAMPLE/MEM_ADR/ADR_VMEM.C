// ��।������ ��砫쭮�� ���� ����������

#include "sysp.h"

unsigned Get_Seg_Vmem(void) {

	unsigned char   mode;
	unsigned seg_address;

	_asm {
		mov ah,0Fh
		int 10h
		mov mode,al
	}

	if((mode >= 0) && (mode <= 6))
		seg_address = 0xB800;

	else if(mode == 7)
		seg_address = 0xB000;


	else if((mode >= 0x0D) && (mode <= 0x13))
		seg_address = 0xA000;

	else seg_address = 0x0;

	return(seg_address);
}


main() {

	unsigned char   far *ptr;
	unsigned seg_addr;

	_asm {
		xor ax,ax
		mov al,4
		int 10h
	}

	seg_addr = Get_Seg_Vmem();

	ptr = (unsigned char far*) (FP_MAKE(seg_addr, 0x0));
	*ptr = (unsigned char) 0xFF;

	ptr = (unsigned char far*) (FP_MAKE(0xB800, 0x2000));
	*ptr = (unsigned char) 0xFF;


	getch();
}

