//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Bar.rc
//
#define IDR_HAND_BAR                    101
#define IDR_MAINFRAME                   128
#define ID_TOOL_EXIT                    32771
#define ID_BUTTON40001                  40001
#define ID_BUTTON40002                  40002
#define ID_BUTTON40003                  40003
#define ID_BUTTON40004                  40004
#define ID_BUTTON40005                  40005
#define ID_FILE_NEW                     0xE100
#define ID_FILE_OPEN                    0xE101
#define ID_FILE_SAVE                    0xE103
#define ID_FILE_PRINT                   0xE107
#define ID_EDIT_COPY                    0xE122
#define ID_EDIT_CUT                     0xE123
#define ID_EDIT_PASTE                   0xE125
#define ID_APP_ABOUT                    0xE140

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
