//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Status.rc
//
#define ID_INDICATOR_ADD                1
#define IDR_MENU                        101
#define ID_INDICATOR_PROGRESS           102
#define ID_INDICATOR_TEXT               103
#define ID_WORK_PROCESS                 40001
#define ID_WORK_DIRECT_ADD              40006
#define ID_WORK_ON_SWITCH_TEXT          40007
#define ID_WORK_DIRECT_SUB              40008
#define ID_WORK_DISABLE_ADDSUB          40009
#define ID_WORK_EXIT                    40010
#define ID_TIMER_CHECK                  0xE001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
