// ���������� ���� ��� ���������� �����/������
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>

class convert
{
public:
	void GetString()  { cin >> sText; }
	void ShowString() { cout << sText << "\n"; }
	int ConvertString();
	void DummyString();
private:
	char sText[80];
};

int  convert::ConvertString(void) 
{
	int i;

	for(i = 0; sText[i] != '\0'; i++ ) {
		sText[i] = tolower(sText[i]);
	}
	return i;
}

inline void convert::DummyString(void) 
{
	int i = 0;

	while(sText[i++]) 
		sText[i] = 0;
}


void main() 
{
	convert ObjectA;

	ObjectA.GetString();
	ObjectA.ConvertString();
	ObjectA.ShowString();

	convert *pObjectB = new convert;

	pObjectB->GetString();
	pObjectB->ConvertString();
	pObjectB->ShowString();
}
