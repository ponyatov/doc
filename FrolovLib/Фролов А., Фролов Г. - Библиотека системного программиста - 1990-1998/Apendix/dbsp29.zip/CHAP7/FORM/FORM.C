#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void DecodeStr(char *szString);
char DecodeHex(char *str);

void main(int argc, char *argv[])
{
  char * szMethod;
  char * szQueryString;
  char szBuf[4096];

  szMethod = getenv("REQUEST_METHOD");
  if(!strcmp(szMethod, "POST"))
  {
    printf("Content-type: text/html\n\n");
    printf("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 3.2//EN\">");
    printf("<HTML><HEAD><TITLE>XYZ Incorporation</TITLE></HEAD><BODY>");
    printf("<H1>������ � �����</H1>");
    printf("<P>����� ������������ ������ ����� GET");
    printf("<P>REQUEST_METHOD = %s", szMethod);
    printf("</BODY></HTML>");
    return;
  }
  
  else if(!strcmp(szMethod, "GET"))
  {
    szQueryString = getenv("QUERY_STRING");
    
    printf("Content-type: text/html\n\n");
    printf("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 3.2//EN\">");
    printf("<HTML><HEAD><TITLE>XYZ Incorporation</TITLE></HEAD><BODY>");

    printf("<H1>��������� ������ ��������� CGI</H1>");
    printf("<P>QUERY_STRING = %s", szQueryString);

    strcpy(szBuf, szQueryString);

    DecodeStr(szBuf);

    printf("<P>Decoded QUERY_STRING = %s", szBuf);


    printf("</BODY></HTML>");
  }
}

void DecodeStr(char *szString)
{
  int src;
  int dst;
  char ch;

  for(src=0, dst=0; szString[src]; src++, dst++)
  {
    ch = szString[src];
    ch = (ch == '+') ? ' ' : ch;
    szString[dst] = ch;
    
    if(ch == '%')
    {
      szString[dst] = DecodeHex(&szString[src + 1]);
      src += 2;
    }
  }
  szString[dst] = '\0';
}

char DecodeHex(char *str)
{
  char ch;

  ch = (str[0] >= 'A' ? ((str[0] & 0xdf) - 'A') + 10 : (str[0] - '0'));
  ch *= 16;
  ch += (str[1] >= 'A' ? ((str[1] & 0xdf) - 'A') + 10 : (str[1] - '0'));

  return ch;
}
