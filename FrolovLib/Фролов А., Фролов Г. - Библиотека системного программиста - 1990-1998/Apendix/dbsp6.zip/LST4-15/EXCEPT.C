#include <stdio.h>
#include <dos.h>
#include <conio.h>
#include <stdlib.h>
#include "tos.h"

void prg_abort(int err);

// ����� ⥪�饩 ��ப� ��� �뢮�� �� ��࠭

extern unsigned int y;

// ��ࠡ��稪� �᪫�祭��

void  exception_0(void) { prg_abort(0); }
void  exception_1(void) { prg_abort(1); }
void  exception_2(void) { prg_abort(2); }
void  exception_3(void) { prg_abort(3); }
void  exception_4(void) { prg_abort(4); }
void  exception_5(void) { prg_abort(5); }
void  exception_6(void) { prg_abort(6); }
void  exception_7(void) { prg_abort(7); }
void  exception_8(void) { prg_abort(8); }
void  exception_9(void) { prg_abort(9); }
void  exception_A(void) { prg_abort(0xA); }
void  exception_B(void) { prg_abort(0xB); }
void  exception_C(void) { prg_abort(0xC); }
void  exception_D(void) { prg_abort(0xD); }
void  exception_E(void) { prg_abort(0xE); }
void  exception_F(void) { prg_abort(0xF); }
void  exception_10(void) { prg_abort(0x10); }
void  exception_11(void) { prg_abort(0x11); }
void  exception_12(void) { prg_abort(0x12); }
void  exception_13(void) { prg_abort(0x13); }
void  exception_14(void) { prg_abort(0x14); }
void  exception_15(void) { prg_abort(0x15); }
void  exception_16(void) { prg_abort(0x16); }
void  exception_17(void) { prg_abort(0x17); }
void  exception_18(void) { prg_abort(0x18); }
void  exception_19(void) { prg_abort(0x19); }
void  exception_1A(void) { prg_abort(0x1A); }
void  exception_1B(void) { prg_abort(0x1B); }
void  exception_1C(void) { prg_abort(0x1C); }
void  exception_1D(void) { prg_abort(0x1D); }
void  exception_1E(void) { prg_abort(0x1E); }
void  exception_1F(void) { prg_abort(0x1F); }

// ------------------------------
// ���਩�� ��室 �� �ணࠬ��
// ------------------------------

void prg_abort(int err) {

	vi_print(1,y++,"!!! ---> �ந��諮 �᪫�祭��", 0xc);

	real_mode(); // �����頥��� � ॠ��� ०��

// � ॠ�쭮� ०��� �뢮��� ᮮ�饭�� �� �᪫�祭��

	gotoxy(1, ++y);
	cprintf(" �᪫�祭�� %X, ������ ���� �������", err);
	getch();

	textcolor(WHITE);
	textbackground(BLACK);
	clrscr();
	exit(0);

}
