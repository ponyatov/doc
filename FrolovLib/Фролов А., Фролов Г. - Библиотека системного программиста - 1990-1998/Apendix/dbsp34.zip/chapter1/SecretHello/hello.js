document.write("<HR>");
document.write("Hello from JavaScript!");
document.write("<HR>");
