// Single.h

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"      

/////////////////////////////////////////////////////////////////////////////////
// ����� CSingleApp:
class CSingleApp : public CWinApp
{
public:
	CSingleApp();

// Overrides
	//{{AFX_VIRTUAL(CSingleApp)
public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CSingleApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
