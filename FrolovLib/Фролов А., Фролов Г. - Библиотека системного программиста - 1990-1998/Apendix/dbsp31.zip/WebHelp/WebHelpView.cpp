// WebHelpView.cpp : implementation of the CWebHelpView class
//

#include "stdafx.h"
#include "WebHelp.h"

#include "WebHelpDoc.h"
#include "WebHelpView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWebHelpView

IMPLEMENT_DYNCREATE(CWebHelpView, CView)

BEGIN_MESSAGE_MAP(CWebHelpView, CView)
	//{{AFX_MSG_MAP(CWebHelpView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWebHelpView construction/destruction

CWebHelpView::CWebHelpView()
{
	// TODO: add construction code here

}

CWebHelpView::~CWebHelpView()
{
}

BOOL CWebHelpView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CWebHelpView drawing

void CWebHelpView::OnDraw(CDC* pDC)
{
	CWebHelpDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CWebHelpView printing

BOOL CWebHelpView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CWebHelpView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CWebHelpView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CWebHelpView diagnostics

#ifdef _DEBUG
void CWebHelpView::AssertValid() const
{
	CView::AssertValid();
}

void CWebHelpView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CWebHelpDoc* CWebHelpView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWebHelpDoc)));
	return (CWebHelpDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWebHelpView message handlers
