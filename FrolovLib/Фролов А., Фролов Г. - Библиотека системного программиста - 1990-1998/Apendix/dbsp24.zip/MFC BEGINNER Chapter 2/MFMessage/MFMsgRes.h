//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MFMessage.rc
//
#define IDR_MENU                        101
#define ID_TEST_BEEP                    40001
#define ID_TEST_EXIT                    40002
#define ID_TEST_INAPPCLASS              40003
#define ID_TEST_INFRAMECLASS            40004
#define ID_TEST_INBOTHCLASS             40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
