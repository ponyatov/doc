// (C) ������ �.�., 1995
// ����� E-mail: frolov@glas.apc.org

#include <windows.h>

#define	COMM_MSRSHADOW	35
#define	MSR_CTS			0x10
#define	MSR_DSR			0x20
#define	MSR_RI			0x40		
#define	MSR_RLSD			0x80

LPBYTE	GetCommMSRShadow( int nCid );

int PASCAL WinMain( HANDLE hInstance, HANDLE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow )
{

	int 		idComDev;
	LPBYTE	lpMSRShadow;
	BOOL		bRLSD;

	idComDev = OpenComm("COM2", 1024, 128);

	if (idComDev < 0) {

		MessageBox(NULL, "Error Open", NULL, MB_OK);
		return 0;
	}

	lpMSRShadow = GetCommMSRShadow(idComDev);
	bRLSD = (*lpMSRShadow) & MSR_RLSD;

	if( bRLSD )
		MessageBox(NULL, "CD is high", NULL, MB_OK);
	else
		MessageBox(NULL, "CD is low", NULL, MB_OK);


	CloseComm(idComDev);

   return 0;
}


LPBYTE	GetCommMSRShadow( int nCid ) {

	return (((LPBYTE) SetCommEventMask( nCid, 0 )) + COMM_MSRSHADOW );
}