// Multi.h 
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       

//////////////////////////////////////////////////////////////
// ����� CMultiApp

class CMultiApp : public CWinApp
{
public:
   CMultiApp();

// Overrides
   //{{AFX_VIRTUAL(CMultiApp)
public:
   virtual BOOL InitInstance();
   //}}AFX_VIRTUAL

// Implementation
   //{{AFX_MSG(CMultiApp)
   afx_msg void OnAppAbout();
   //}}AFX_MSG

   // ����� CMultiApp ����� �������� ���������
   DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
