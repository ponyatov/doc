//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DialogBar.rc
//
#define IDD_DIALOG_BAR                  101
#define IDC_COMBO1                      1000
#define IDC_RADIO1                      1004
#define IDC_RADIO_LEFT                  1004
#define IDC_RADIO2                      1005
#define IDC_RADIO_CENTER                1005
#define IDC_RADIO3                      1006
#define IDC_RADIO_RIGHT                 1006
#define IDC_BUTTON1                     1007
#define IDC_BUTTON_SET                  1007
#define IDC_BUTTON2                     1008
#define IDC_BUTTON_CLEAR                1008
#define IDC_COMBO_COLOUR                1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
