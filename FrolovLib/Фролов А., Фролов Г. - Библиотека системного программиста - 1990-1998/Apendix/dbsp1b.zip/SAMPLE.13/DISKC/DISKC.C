#include <stdio.h>
#include <conio.h>
#include <bios.h>
#include <dos.h>
#include <stdlib.h>

char _far diskbuf[512];

void main(void);

void main(void) {

	 unsigned status = 0, i;
	 struct diskinfo_t di;

	 di.drive    = 0;
	 di.head     = 0;
	 di.track    = 0;
	 di.sector   = 1;
	 di.nsectors = 1;
	 di.buffer   = diskbuf;

	 for(i = 0; i < 3; i++) {
		  status = _bios_disk(_DISK_READ, &di) >> 8;
		  if( !status ) break;
	 }

}

