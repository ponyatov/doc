//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HttpView.rc
//
#define IDD_HTTPVIEW_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_URL_ADDRESS            1000
#define IDC_EDIT_VIEW                   1001
#define IDC_PROGRESS                    1002
#define IDC_BUTTON_CONNECT              1003
#define IDC_BUTTON_GET                  1003
#define IDC_EDIT_STATUS                 1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
