#include <dos.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

void main(int argc, char *argv[]);
void main(int argc, char *argv[]) {

	 unsigned fattr;

	 _dos_getfileattr(argv[1], &fattr);

	 _dos_setfileattr(argv[1], fattr ^ _A_RDONLY);
}

