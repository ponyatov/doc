// DaterSet.h : interface of the CDaterSet class
//
/////////////////////////////////////////////////////////////////////////////

class CDaterSet : public CRecordset
{
public:
	CDaterSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CDaterSet)

// Field/Param Data
	//{{AFX_FIELD(CDaterSet, CRecordset)
	CString	m_NAME;
	CString	m_ADDRESS;
	long	m_PRIORITY;
	CString	m_PHONE;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaterSet)
	public:
	virtual CString GetDefaultConnect();	// Default connection string
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};
