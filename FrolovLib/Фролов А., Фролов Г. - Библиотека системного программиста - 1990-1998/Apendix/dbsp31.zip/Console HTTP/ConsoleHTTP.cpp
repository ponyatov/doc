#include <afx.h> 		// header file for MFC
#include <afxinet.h> 	// header file for WinInet
#include <iostream.h>	// header file for input/output stream
#include <stdlib.h>	// header file for standard library functions


int main(int argc, char* argv[])
{
	CInternetSession* m_InternetSession = NULL;
	
	if (argc < 2)
	{
		cout << "Programm format: ConsoleFtp <URL>" << endl;
		cout << "  <URL> - URL address of WWW" << endl << endl;
		return -1;
	}

	CString sUrlAdress;
	sUrlAdress = argv[1];
	
	cout << "URL address: " << sUrlAdress << endl << endl;

	
	CString sServer;
	CString sObject;
	INTERNET_PORT nPort;
	DWORD dwServiceType;
	

	if (!AfxParseURL(sUrlAdress, dwServiceType, sServer, sObject, nPort))
	{
		cout << "AfxParseURL Error" << endl;
		
		return -1;
	}

	if(dwServiceType != AFX_INET_SERVICE_HTTP)
	{
			cout << "URL Address not WWW server" << endl;
			
			return -1;
	}

	m_InternetSession = new CInternetSession("HTTP Connector");	

	CHttpFile* pFile=NULL;	
	CHttpConnection*  m_HttpConnection = NULL;

	try
	{
		m_HttpConnection = m_InternetSession -> GetHttpConnection( sServer );

	
		pFile = m_HttpConnection -> OpenRequest(	CHttpConnection::HTTP_VERB_HEAD,
			//HTTP_VERB_GET,
																sObject
															);

		CString headerInfo(_T("Accept: text/*\r\nUser-Agent: HTTP Example\r\n"));
	
		BOOL fSuccess;

		if(fSuccess = pFile->AddRequestHeaders(headerInfo))
		{
			if(fSuccess = pFile->SendRequest())
			{
				DWORD dwReturnCode;

				if(fSuccess = pFile->QueryInfoStatusCode(dwReturnCode))
				{
					CString sMessage;
					sMessage.Format("%d",dwReturnCode);

					cout << "SendRequest: " << sMessage << endl << endl;
				}
				else
				{
					cout << "Request Error" << endl << endl;
				}
			}
		}
	
	}
	catch (CInternetException* pEx)
	{
		// ������������ ���������� CInternetException
		TCHAR szErr[1024];  // ��������� ����� ��� ���������

		// ������� ��������� �� ������
		if (pEx->GetErrorMessage(szErr, 1024))
			cout << "Error: " << szErr <<endl <<endl;

		// ������� �����������
		pEx->Delete();
	}

	
	pFile->Close();
	if(pFile)
		delete pFile;


	m_HttpConnection -> Close();

	delete( m_HttpConnection );

	m_InternetSession -> Close();
	delete(m_InternetSession);

	return 0;
} 
