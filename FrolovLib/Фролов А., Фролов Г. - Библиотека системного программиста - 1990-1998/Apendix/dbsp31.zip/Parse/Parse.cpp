#include <afx.h> 		// header file for MFC
#include <afxinet.h> 	// header file for WinInet
#include <iostream.h>	// header file for input/output stream


int main(int argc, char* argv[])
{
	CInternetSession* m_InternetSession = NULL;
	
	CString serverName("saturn");
	CString sUrlAdress;

	if (argc < 2)
	{
		cout << "Programm format: Parse <URL>" << endl;
		cout << "  <URL> - URL address" << endl << endl;
	}

	sUrlAdress = argv[1];
	
	cout << "URL address: " << sUrlAdress << endl << endl;

	
	CString sServer;
	CString sObject;
	INTERNET_PORT nPort;
	DWORD dwServiceType;
	

	if (!AfxParseURL(sUrlAdress, dwServiceType, sServer, sObject, nPort))
	{
		cout << "AfxParseURL Error" << endl;
		
		return -1;
	}
	else
	{

		cout << "Service type: ";

		switch(dwServiceType)
		{
			case AFX_INET_SERVICE_FTP:
				cout << "AFX_INET_SERVICE_FTP" << endl;
				break;

			case AFX_INET_SERVICE_HTTP:
				cout << "AFX_INET_SERVICE_HTTP" << endl;
				break;

			case AFX_INET_SERVICE_GOPHER:
				cout << "AFX_INET_SERVICE_GOPHER" << endl;
				break;
				
			case AFX_INET_SERVICE_FILE:
				cout << "AFX_INET_SERVICE_FILE" << endl;
				break;			

			default:
				cout << dwServiceType << endl;
		}
		
		cout << "Server: " << sServer << endl;
		cout << "Object: " << sObject << endl;
		cout << "Port: " << nPort << endl;
	}


	return 0;
} 
