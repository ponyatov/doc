// WizDlgBarDoc.cpp : implementation of the CWizDlgBarDoc class
//

#include "stdafx.h"
#include "WizDlgBar.h"

#include "WizDlgBarDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWizDlgBarDoc

IMPLEMENT_DYNCREATE(CWizDlgBarDoc, CDocument)

BEGIN_MESSAGE_MAP(CWizDlgBarDoc, CDocument)
	//{{AFX_MSG_MAP(CWizDlgBarDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWizDlgBarDoc construction/destruction

CWizDlgBarDoc::CWizDlgBarDoc()
{
	// TODO: add one-time construction code here

}

CWizDlgBarDoc::~CWizDlgBarDoc()
{
}

BOOL CWizDlgBarDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CWizDlgBarDoc serialization

void CWizDlgBarDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CWizDlgBarDoc diagnostics

#ifdef _DEBUG
void CWizDlgBarDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CWizDlgBarDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWizDlgBarDoc commands
