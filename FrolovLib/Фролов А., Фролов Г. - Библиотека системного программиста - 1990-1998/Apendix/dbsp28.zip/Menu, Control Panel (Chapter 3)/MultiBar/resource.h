//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MultiBar.rc
//
#define IDW_EDIT                        101
#define IDW_SPIN                        102
#define IDR_PLAYER                      103
#define IDR_STYLE                       105
#define IDR_EXTENDED                    107
#define IDR_MENU                        109
#define ID_LEFT                         40001
#define ID_RIGHT                        40002
#define ID_PLAY                         40003
#define ID_STOP                         40004
#define ID_PAUSE                        40005
#define ID_EJECT                        40007
#define ID_TYPE                         40008
#define ID_BUTTON40009                  40009
#define ID_CD_DRV                       40009
#define ID_BUTTON40010                  40010
#define ID_WAVE                         40011
#define ID_UNDERLINE                    40012
#define ID_2_UNDERLINE                  40013
#define ID_SUPERSCRIPT                  40014
#define ID_SUBSCRIPT                    40015
#define ID_TEXT_LEFT                    40017
#define ID_ID_TEXT_CENTER               40018
#define ID_TEXT_RIGHT                   40019
#define ID_TEXT_JUSTIFY                 40020
#define ID_MARK_1                       40021
#define ID_MARK_2                       40022
#define ID_MARK_3                       40023
#define ID_MARK_4                       40024
#define ID_FOTO                         40025
#define ID_PRINTER                      40026
#define ID_DISK                         40027
#define ID_Style                        40029
#define ID_Extended                     40030
#define ID_Buttons                      40031
#define ID_Player                       40031
#define ID_BUTTON40032                  40032
#define ID_ADD                          40032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40033
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
