// LookDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLookDlg dialog
//{{AFX_INCLUDES()
#include "webbrowser.h"
//}}AFX_INCLUDES

class CLookDlg : public CDialog
{
// Construction
public:
	CLookDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLookDlg)
	enum { IDD = IDD_LOOK_DIALOG };
	CButton	m_Forward;
	CButton	m_Back;
	CWebBrowser	m_explorer;
	CString	m_address;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLookDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CLookDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeComboAddress();
	afx_msg void OnButtonRefresh();
	afx_msg void OnButtonStop();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
