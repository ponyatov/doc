#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main(int argc, char *argv[])
{
  char * szQueryString;

  szQueryString = getenv("QUERY_STRING");

  if(!strcmp(szQueryString, "page1"))
    printf("Location: home.htm\n\n");
  
  else if(!strcmp(szQueryString, "page2"))
    printf("Location: books.htm\n\n");
  
  else if(!strcmp(szQueryString, "page3"))
    printf("Location: capital.htm\n\n");

  else
    printf("Location: error.htm\n\n");
}