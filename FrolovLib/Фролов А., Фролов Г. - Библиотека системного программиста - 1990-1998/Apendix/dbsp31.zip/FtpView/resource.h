//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FtpView.rc
//
#define IDD_FTPVIEW_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDI_DIRECTORY                   130
#define IDI_FILE                        131
#define IDC_FTP_LIST                    1000
#define IDC_FTP_ADDRESS                 1001
#define IDC_VIEW                        1002
#define IDC_ON_TOP                      1003
#define IDC_CONNECT                     1004
#define IDC_STATUS                      1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
