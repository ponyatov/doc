// MultiView.h : ����� CMultiView 
//
/////////////////////////////////////////////////////////////////////////////

class CMultiView : public CView
{
protected:
	CMultiView();
	DECLARE_DYNCREATE(CMultiView)

// Attributes
public:
	CMultiDoc* GetDocument();

// Operations
public:

// Overrides
	//{{AFX_VIRTUAL(CMultiView)
	public:
	virtual void OnDraw(CDC* pDC);  
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMultiView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	//{{AFX_MSG(CMultiView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////////////////////////
// ����� GetDocument ������ CMultiView, ������������� ������

#ifndef _DEBUG  
inline CMultiDoc* CMultiView::GetDocument()
   { return (CMultiDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
