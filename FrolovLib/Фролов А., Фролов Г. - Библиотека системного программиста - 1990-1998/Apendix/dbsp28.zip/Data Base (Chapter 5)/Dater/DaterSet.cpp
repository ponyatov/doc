// DaterSet.cpp : implementation of the CDaterSet class
//

#include "stdafx.h"
#include "Dater.h"
#include "DaterSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaterSet implementation

IMPLEMENT_DYNAMIC(CDaterSet, CRecordset)

CDaterSet::CDaterSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CDaterSet)
	m_NAME = _T("");
	m_ADDRESS = _T("");
	m_PRIORITY = 0;
	m_PHONE = _T("");
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}

CString CDaterSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=Address Pad");
}

CString CDaterSet::GetDefaultSQL()
{
	return _T("[TextBase.txt]");
}

void CDaterSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CDaterSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[NAME]"), m_NAME);
	RFX_Text(pFX, _T("[ADDRESS]"), m_ADDRESS);
	RFX_Long(pFX, _T("[PRIORITY]"), m_PRIORITY);
	RFX_Text(pFX, _T("[PHONE]"), m_PHONE);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CDaterSet diagnostics

#ifdef _DEBUG
void CDaterSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CDaterSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
