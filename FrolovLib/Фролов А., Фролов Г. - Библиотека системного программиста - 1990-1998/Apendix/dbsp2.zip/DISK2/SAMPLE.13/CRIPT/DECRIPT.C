#include <stdio.h>
#include <conio.h>
#include <process.h>

void main(int argc, char *argv[])
{
	 char passw[80], filebuf[80], parms[100], ch;

	 _searchenv( "pkunzip.exe", "PATH", filebuf );
	 if(!(*filebuf) ) {
		printf("PKUNZIP not found.\n");
		exit(-2);
	 }

	 printf( "Enter password: " );
	 getpw(passw, 80);
	 sprintf(parms,"-s%s %s",passw,argv[1]);
	 execl( filebuf, parms, parms, NULL );

	 printf( "\nProcess was not execed." );
	 exit( 0 );
}

int getpw( char *buf, int size) {

	int i;
	char ch;

	for(i=0; i<size; ) {
		ch = getch();
		if(ch == 0) ch=getch();
		putch('.');
		*buf = ch;
		if(*buf == 0xd) break;
		i++;
		buf++;

	}
	*buf = 0;


}
