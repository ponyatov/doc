#include <stdio.h>

main() {

	char  *ptr,
			out_str[] = "\aputchar\nputc\a";

	for(ptr = out_str; *ptr; putchar(*(ptr++)) );

}
